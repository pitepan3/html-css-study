# 피그마 링크
https://www.figma.com/file/VviXTbWZ7TAWEWb2lzv5cZ/EVENTS/duplicate

# 텍스트 
```
CALENDAR AND
EVENT TOOLS

+ ADD TO CALENDAR

HTML CSS JavaScript

Digital Workplace
Experience

It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.

CLOSED



AR VR Headsets
Augmented World
Expo 2022

Lorem Ipsum is simply dummy text of the printing and typesetting industry.

14 members




Photoshop Illustrator
Adobe Summit

printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley.

124 members

```
